
				<?php 
					if(!isset($bien_bao_mat_csdl)){exit();}
				?>
				<?php 
					$csdl['ky_danh']='29a057e6e6924c1c6738c3d92cb4e9fd';
					$csdl['mat_khau']='29a057e6e6924c1c6738c3d92cb4e9fd';
				?>
			