<?php 
	if(!isset($bien_bao_mat_csdl)){exit();}
?>
<?php 

	/*vt_1*/$csdl['gd_menu']['tc_mn_hn']="hinh_nen";/*vt_1*/
	
	/*vt_2*/$csdl['gd_menu']['mau_nen']="#0088ff";/*vt_2*/
	
	/*vt_3*/$csdl['gd_menu']['hinh_nen']="l35.jpg";/*vt_3*/
	
	$csdl['gd_menu']['mau_chu_menu_cap_1']="white";
	
	$csdl['gd_menu']['mau_chu_krcv_menu_cap_1']="white";
	
	$csdl['gd_menu']['mau_dau_phan_cach']="white";
	
	$csdl['gd_menu']['tc_mn_krcv_menu']="co";
	
	$csdl['gd_menu']['mau_nen_krcv_menu_cap_1']="#0044ff";
	
	
	
	
	$csdl['gd_menu']['tc_mn_hn_cd']="mau_nen";
	
	$csdl['gd_menu']['mau_nen_cd']="blue";
	
	$csdl['gd_menu']['hinh_nen_cd']="l35.jpg";
	
	$csdl['gd_menu']['hn_theo_chieu_doc_cd']="co";
	
	$csdl['gd_menu']['mau_chu_menu_cap_duoi']="white";
	
	$csdl['gd_menu']['mau_chu_krcv_menu_cap_duoi']="red";
	
	$csdl['gd_menu']['tc_mn_krcv_menu_cap_duoi']="co";
	
	$csdl['gd_menu']['mau_nen_krcv_menu_cap_duoi']="yellow";
	
	$csdl['gd_menu']['mau_duong_vien_menu_cap_duoi']="white";

?>
