<?php 
	if(!isset($bien_bao_mat_csdl)){exit();}
?>
<?php 

	$csdl['gd_menu']['tc_mn_hn']="mau_nen";
	
	$csdl['gd_menu']['mau_nen']="#0088ff";
	
	$csdl['gd_menu']['hinh_nen']="";

?>
		