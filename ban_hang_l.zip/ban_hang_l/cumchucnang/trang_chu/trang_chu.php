<?php 
	chong_pha_hoai();
	//echo "viet code trang chu tai day";

	include("cumchucnang/trang_chu/san_pham_ngoai_trang_chu.php");
?>