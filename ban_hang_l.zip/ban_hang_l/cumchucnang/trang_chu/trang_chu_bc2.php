<?php 
	chong_pha_hoai();


	include("cumchucnang/trang_chu/san_pham_ngoai_trang_chu_bc2.php");
?>