<?php 
	chong_pha_hoai();
?>
<tr>
	<td width="770px" valign="top">
		<?php 
			include("cumchucnang/bien_luan_phan_than/bien_luan_phan_than_bc2.php");
		?>
	</td>
	<td width="220px" valign="top" align="center" >
		<?php 
			
			include("cumchucnang/menu_trai/menu_trai_2_bc2.php");
			echo '<div class="v_c1"></div>';
			
			include("cumchucnang/san_pham_ban_chay/san_pham_ban_chay_bc2.php");
			
			echo '<div class="v_c1"></div>';
			
			include("cumchucnang/thong_ke/thong_ke_bc2.php");
			echo '<div class="v_c1"></div>';
			include("cumchucnang/quang_cao_phai/quang_cao_phai_bc2.php");
		?>
	</td>
</tr>