<?php 
	chong_pha_hoai();
?>
<tr>
	<td valign="top">
		<?php 
			include("cumchucnang/bien_luan_phan_than/bien_luan_phan_than_bc3.php");
		?>
	</td>
</tr>