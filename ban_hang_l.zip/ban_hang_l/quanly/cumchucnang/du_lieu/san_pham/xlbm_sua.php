<?php 
	chong_pha_hoai();
?>
<?php 
	if(trim($_POST['ten'])=="")
	{
		thong_bao_a1("Không được bỏ trống tên sản phẩm");
	}
?>