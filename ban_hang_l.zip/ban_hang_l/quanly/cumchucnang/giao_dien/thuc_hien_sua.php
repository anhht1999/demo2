<?php 
	chong_pha_hoai();
?>
<?php 
	$giao_dien=$_POST['giao_dien'];
	sua_thong_so($giao_dien,"mau_giao_dien");
?>