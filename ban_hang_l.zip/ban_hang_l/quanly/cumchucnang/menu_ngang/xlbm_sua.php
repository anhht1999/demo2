<?php 
	chong_pha_hoai();
?>
<?php 
	if(trim($_POST['ten_menu'])=="")
	{
		thong_bao_a1("Không được bỏ trống tên menu");
	}
?>