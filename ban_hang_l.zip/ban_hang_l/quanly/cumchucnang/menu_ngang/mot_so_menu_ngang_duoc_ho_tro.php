<?php 
	chong_pha_hoai();
?><table width="990px" id="er" style="margin-top:6px;text-align:left">
		<tr>

			<td>
				Một số menu ngang được hỗ trợ
			</td>
		</tr>
		<tr>
			<td>
				<div style="background:#f9f9f9;text-align:left;margin:6px 6px 6px 0px;color:#666666;font-size:14px">
						<div style="margin-left:6px">
							<b>1)</b> Trang chủ : <b>index.php</b><br>

							<b>2)</b> Hiển thị một tin : mặc định dạng menu này được hỗ trợ 16 link <br>
							<div style="margin:6px 6px 6px 20px;height:100px;width:600px;border:1px solid #cccccc;overflow:scroll;">
								?thamso=xuat_mot_tin&id=1<br>
								?thamso=xuat_mot_tin&id=2<br>
								?thamso=xuat_mot_tin&id=3<br>

								?thamso=xuat_mot_tin&id=4<br>
								?thamso=xuat_mot_tin&id=5<br>
								?thamso=xuat_mot_tin&id=6<br>
								?thamso=xuat_mot_tin&id=7<br>
								?thamso=xuat_mot_tin&id=8<br>

								?thamso=xuat_mot_tin&id=9<br>
								?thamso=xuat_mot_tin&id=10<br>
								?thamso=xuat_mot_tin&id=11<br>
								?thamso=xuat_mot_tin&id=12<br>
								?thamso=xuat_mot_tin&id=13<br>

								?thamso=xuat_mot_tin&id=14<br>
								?thamso=xuat_mot_tin&id=15<br>
								?thamso=xuat_mot_tin&id=16
							</div>
							Cú pháp của nó dạng <b>?thamso=xuat_mot_tin&id=<b style="color:red">so</b></b>

							với <b style="color:red">so</b> mang giá trị từ <b style="color:red">1 --> 16</b><br>
							<div class="cao_3_px"></div>
							Dữ liệu trong menu này , bạn có thể vào <b>Dữ liệu --> Quản lý dữ liệu --> Hiển thị một tin</b> để thay đổi <br>
							Tại cái trang mà bạn mới vào sẽ cho sữa 16 dữ liệu tương ứng với 16 link liên kết của menu dạng 'Hiển thị một tin' này<br>

							<div class="cao_3_px"></div>
							<b>3)</b> Xuất toàn bộ sản phẩm : <b>?thamso=xuat_toan_bo_san_pham</b><br>
							<b>4)</b> Đăng ký : <b>?thamso=dang_ky</b><br>
							<b>5)</b> Tin tức : <b>?thamso=xuat_tin_tuc</b><br>

							<b>6)</b> Liên hệ : <b>?thamso=lien_he</b><br>
						</div>
				</div>
			</td>
		</tr>
	</table>
<script>
	table_css_1("er");
</script>
