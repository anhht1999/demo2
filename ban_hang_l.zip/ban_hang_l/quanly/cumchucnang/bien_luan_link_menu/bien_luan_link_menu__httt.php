<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=them_nick_yahoo" class="lienket_phanthan">Thêm liên lạc</a>';
	echo "<br>";
	echo '<a href="?thamso=quan_ly_phan_ho_tro_truc_tuyen" class="lienket_phanthan" >Quản lý</a>';
?>