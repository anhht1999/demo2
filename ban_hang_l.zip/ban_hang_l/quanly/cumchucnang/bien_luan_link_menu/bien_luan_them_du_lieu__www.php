<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=them_san_pham" class="lienket_phanthan">Thêm sản phẩm</a>';
	echo "<br>";
	echo '<a href="?thamso=them_tin_tuc" class="lienket_phanthan" >Thêm tin tức</a>';
?>