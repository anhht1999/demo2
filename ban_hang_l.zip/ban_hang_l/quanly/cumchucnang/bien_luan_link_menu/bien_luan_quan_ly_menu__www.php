<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=quan_ly_menu_doc" class="lienket_phanthan">Quản lý menu dọc</a>';
	echo "<br>";
	echo '<a href="?thamso=quan_ly_menu_ngang" class="lienket_phanthan" >Quản lý menu ngang</a>';
?>