<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=them_quang_cao_phai" class="lienket_phanthan">Thêm</a>';
	echo "<br>";
	echo '<a href="?thamso=quan_ly_quang_cao_phai" class="lienket_phanthan" >Quản lý</a>';
?>