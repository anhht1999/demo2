<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=bien_luan_link_menu__qct" class="lienket_phanthan">Quãng cáo trái</a>';
	echo "<br>";
	echo '<a href="?thamso=bien_luan_link_menu__qcp" class="lienket_phanthan" >Quãng cáo phải</a>';
?>