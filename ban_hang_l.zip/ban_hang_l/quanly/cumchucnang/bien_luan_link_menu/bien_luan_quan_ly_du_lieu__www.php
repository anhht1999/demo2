<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=quan_ly_san_pham" class="lienket_phanthan">Sản phẩm</a>';
	echo "<br>";
	echo '<a href="?thamso=quan_ly_tin_tuc" class="lienket_phanthan" >Tin tức</a>';
	echo "<br>";
	echo '<a href="?thamso=quan_ly_du_lieu_mot_tin" class="lienket_phanthan" >Hiển thị một tin</a>';
?>