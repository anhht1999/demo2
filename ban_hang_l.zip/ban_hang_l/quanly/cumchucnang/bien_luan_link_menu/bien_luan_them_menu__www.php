<?php 
	chong_pha_hoai();
?>
<?php 
	echo '<a href="?thamso=them_menu_doc" class="lienket_phanthan">Thêm menu dọc</a>';
	echo "<br>";
	echo '<a href="?thamso=them_menu_ngang" class="lienket_phanthan" >Thêm menu ngang</a>';
?>