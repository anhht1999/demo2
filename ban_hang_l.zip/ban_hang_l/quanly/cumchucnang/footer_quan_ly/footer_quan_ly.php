<?php 
	chong_pha_hoai();
?>
<style type="text/css" >
	a.lien_ket_ll
	{
		color:blue;
		text-decoration:none;
	}
	a.lien_ket_ll:hover 
	{
		color:red;
	}
</style>
<table border="0" width="990px" bgcolor="white" height="60px" >

	<tr>
		<td align="center" width="450px"  >
		<b style="color:blue;cursor:default" >
		<a href="1.html" target="_blank" class="lien_ket_ll" >Code web bán hàng E lờ</a></b>
		</td>

	</tr>


</table>
<br>