<?php 
	chong_pha_hoai();
?>
<br>
<a href='?thamso=ksp&vt=1' class="lienket_phanthan" >Khung 1 ( Khung "<?php echo $ten_ksp_1; ?>" )</a><br>
<a href='?thamso=ksp&vt=2' class="lienket_phanthan" >Khung 2 ( Khung "<?php echo $ten_ksp_2; ?>" )</a><br>
<a href='?thamso=ksp&vt=3' class="lienket_phanthan" >Khung 3 ( Khung "<?php echo $ten_ksp_3; ?>" )</a><br>
<a href='?thamso=ksp&vt=4' class="lienket_phanthan" >Khung 4 ( Khung "<?php echo $ten_ksp_4; ?>" )</a><br>
<a href='?thamso=sua_ten_khung_san_pham' class="lienket_phanthan" >Sửa tên khung sản phẩm </a><br>
<a href='?thamso=sua_ssp_trong_khung' class="lienket_phanthan" >Sửa số sản phẩm trong khung</a><br>
<!--<a href='?thamso=sxcp' class="lienket_phanthan" >Bật tắt / sắp xếp khung sản phẩm </a><br>-->
<a href='?thamso=bt_sx_ksp' class="lienket_phanthan" >Bật tắt / sắp xếp khung sản phẩm </a><br>