<?php 
	chong_pha_hoai();
?>
<br>
<a href='?thamso=kvb&vt=1' class="lienket_phanthan" >Khung 1 ( Khung "<?php echo $ten_kbv_1; ?>" )</a><br>
<a href='?thamso=kvb&vt=2' class="lienket_phanthan" >Khung 2 ( Khung "<?php echo $ten_kbv_2; ?>" )</a><br>
<a href='?thamso=kvb&vt=3' class="lienket_phanthan" >Khung 3 ( Khung "<?php echo $ten_kbv_3; ?>" )</a><br>
<a href='?thamso=kvb&vt=4' class="lienket_phanthan" >Khung 4 ( Khung "<?php echo $ten_kbv_4; ?>" )</a><br>
<a href='?thamso=bt_sx_ksp' class="lienket_phanthan" >Bật tắt / sắp xếp khung văn bản </a><br>