<?php 
	chong_pha_hoai();
?>
<br><br>
<div style="font-size:22px" >Nếu muốn bật tắt , sắp xếp các khung văn bản thì tiến hành bật tắt , sắp sếp các khung cột phải tại liên kết
dưới đây : </div> <br>

<a href="?thamso=sxcp" class="lienket_phanthan" >Sắp xếp , bật tắt các khung cột phải</a> 

<br><br>
<br>
Có thể vào menu <b>Cụm chức năng</b> rồi chọn menu <b>Sắp xếp , bật tắt các khung cột phải</b> để tiến hành 
bật tắt , sắp xếp các khung văn bản

<br><br>