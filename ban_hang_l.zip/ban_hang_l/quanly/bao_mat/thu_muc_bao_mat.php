<?php 
	chong_pha_hoai();
?>
<?php 
	$thu_muc_bao_mat="js/";
	$thu_muc_bao_mat=$thu_muc_bao_mat."";
?>
		