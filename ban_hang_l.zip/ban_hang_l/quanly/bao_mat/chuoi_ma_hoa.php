
<?php 
	if(!isset($bien_bao_mat)){exit();}
	if($bien_bao_mat!="co"){exit();}
?>
<?php 
	$chuoi_ma_hoa="8J5_5p(VPu@kcGKL_3LKY@P4Vryc`0}6!LekgPNMn!^a:y6t-Y4=GRTUGe0--g@E:]R-0sv3rE]k[59(QXz[mz1S_)9_hPAPzfxt_";
?>
		