<?php
	mysql_connect("localhost","root","");
	mysql_select_db("ban_hang_l");
	mysql_query('SET NAMES "UTF8"');
	$ten_danh_dau__kkk="ppp__ol_k___";
?>